# RescuePC Bully PC Preview 0.1

Private release candidate prepared 2026-11-15. Not published and not a finished or universal fix. No account, terminal commands or downloads are used by Setup. The EXE is unsigned; Windows may show an unknown-publisher warning. Keep the extracted folder because it contains the payload and your rollback backups.

## Install
1. Extract this folder to a writable location. Save and close Bully.
2. Double-click RescuePC Bully Setup.exe and choose the game folder.
3. Choose your resolution (Use display selects the monitor containing Setup). FOV is a percentage multiplier, not degrees. Default 100% preserves the existing widescreen correction's standard view; Tyler uses 83%.
4. Optionally apply the control layout. It is OFF by default to preserve existing bindings. Click a binding and press a keyboard key, or type a native mouse code shown below the grid. Mouse 5 hold-sprint is fixed in this preview to match its prompt. Keyboard sensitivity and unrelated profile bytes are preserved. Menu arrows / Enter / Backspace stay independent of gameplay bindings. F10 also pauses.
5. Install / update, then launch normally through Steam. The existing ASI loader loads installed plugins automatically on subsequent launches. Setup is only needed to install, configure or undo.

## Compatibility and dependencies
Only the tested Steam PC 1.200 Bully.exe is accepted (SHA-256 36FF31682081A61BA564CB5E09CD6240F79791879CF1FBFB8E6252F75FADDC6C). Other executables fail without changes. This preview requires an already installed, working dinput8 ASI loader. It does not bundle or download third-party fixes. The loader and other mods can conflict; this exact existing combination was used for development. Controller input is left to the game; testing has focused on keyboard/mouse.

FPS selection updates an existing SilentPatch installation only; it has no effect without SilentPatch. FOV selection updates an existing Bully Widescreen Fix only; it has no effect without that plugin. Those projects retain their own authorship and licenses. They are not our work and are not included in this ZIP. See https://github.com/CookiePLMonster/SilentPatch and https://github.com/ThirteenAG/WidescreenFixesPack for attribution/reference, not an instruction to download anything.

Windowed borderless and VSync are requested. The game's windowed presentation follows the desktop refresh rate; Setup never changes the monitor refresh rate. Arbitrary refresh rates, multi-monitor behavior and exclusive-fullscreen combinations have not been certified. Only 30/60 FPS are offered while simulation timing remains unresolved. No CPU, RAM, voltage, driver or power-plan changes are performed. MSAA is a saved request; the current renderer may retain vendor-dependent nonmaskable MSAA. Explicit 4-sample normalization exists only in staged V2 source and has not been validated or installed.

## Backup and undo
Before each write, Setup saves the exact previous file beside itself under Backups, plus previous graphics registry values. It modifies only its listed plugins/configuration, the small HUD prompt delta, the optional ControllerSettings layout and graphics registry values. It never replaces save slots or disables Windows security. Undo last install works for the latest installation and refuses if those files/settings were subsequently changed, preserving later edits. Retain older backup folders for manual recovery. If Windows blocks writes to Documents through Controlled Folder Access, installation is rolled back and the error is shown; allow only the app you trust through Windows Security if needed, rather than disabling protection.

## Current work and limits
- Native menu input is separated from sprint/fire; Mouse 5 can be held for the sprint pulse behavior. Physical F12 is reserved internally by this preview; avoid binding another action to it.
- The custom M5 keycap is original artwork. Setup patches exactly 4096 bytes of a hash-verified original HUDElems.nft; no Rockstar assets are distributed. An already patched supported file is accepted; other HUD mods are rejected.
- Experimental render V1 is optional and OFF by default: material filtering, presentation diagnostics and presentation parameter guard. Visual flashing remains reported. Included render binary is the exact observed V1 runtime; the archived render source is later V2 development work and will not reproduce that V1 binary. V2 is not installed by this package. The controls and Setup source correspond to the packaged versions.
- A 20-second presentation sample on Tyler's system measured about 59.72 FPS, median 16.668 ms, p99 19.241 ms, seven intervals above 25 ms and none above 50 ms. This short sample is not proof of universal smoothness or that simulation/animation is fixed.
- Still unresolved: using/throwing all throwable objects, keyboard movement feel, NPC animation/chase issues, skin/screen flashing, and broad gameplay regression coverage. Do not advertise these as fixed.
- The requested in-game SP build-label replacement is not implemented. rescuepcrepairs.com branding appears in this Setup, not the game menu. Preserve third-party credits.
- This changes presentation and controls; it does not replace the original models/textures with modern remake assets.

## Sharing
Share only this preview folder/ZIP after review and testing. Never share D:\Bully-Fix-Kit or the release checkpoints: those contain private saves, complete game assets and third-party runtime dependencies. No upload or publication has been performed. Before calling this a finished public release, resolve the reported gameplay/visual issues, establish reproducible release sources for rendering, and test install/undo on a clean supported installation and other displays.

## Build
Controls: Visual Studio 2019 x86 C++ tools, compile Tyler.BullyFix.cpp as an optimized /MT DLL linked to user32.lib, extension .asi. Archived build scripts reflect the development environment. Setup: .NET Framework 4 C# compiler, /target:winexe, references System.Drawing.dll, System.Windows.Forms.dll and System.Web.Extensions.dll, /win32icon:Source\favicon.ico. Run Setup with --verify for package hashes, artwork and profile preservation/file rollback self-tests. Self-tests do not start the game or change its registry settings. Full end-to-end install/gameplay verification remains pending.